extern int ioctl(int __fd, unsigned long int __request, ...);
